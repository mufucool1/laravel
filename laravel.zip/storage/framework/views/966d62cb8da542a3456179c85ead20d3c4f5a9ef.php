

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
               
                <div class="card-header">Welcome <?php echo e($user->name); ?></div>
                <?php if($profile_exists==1): ?>
                <div class="card-body">
                    <p><span class="label">Title:</span> <?php echo e($user->profile->title); ?></p>
                    <p><span class="label">Description:</span> <?php echo e($user->profile->description); ?></p>
                    <p><span class="label">Url:</span> <a target="_blank" href="<?php echo e($user->profile->url); ?>"><?php echo e($user->profile->url); ?></a></p>
                </div>
                <?php else: ?>
                <div class="card-body">
                    Your profile is not created!
                </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mufaddal\resources\views/profile.blade.php ENDPATH**/ ?>