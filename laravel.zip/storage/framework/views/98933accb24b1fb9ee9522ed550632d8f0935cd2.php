<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel\mufaddal\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>