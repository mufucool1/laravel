<?php

Route:: get ('/test', function () {
   return 'Welcome to index';
});

/*Route::get('/usercontroller/path',[
   'middleware' => 'First',
   'uses' => 'UserController@showPath'
]);*/